#include "startwindow.h"

StartWindow::StartWindow(QWidget *parent)
    : QMainWindow(parent)
{}

StartWindow::~StartWindow() {}
