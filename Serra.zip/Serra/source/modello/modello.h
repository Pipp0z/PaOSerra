#ifndef MODELLO_H
#define MODELLO_H

#include "serra.h"
#include <QObject>
#include <QDomDocument>
#include <QFile>
#include <QString>
#include <QDate>
#include <QTime>
#include <QtXml>
#include <QVector>
#include <QDir>
#include "serra.h"

class modello
{
private:
    Serra serra;
public:
    modello();
    /*
     * @brief saveInfo() funzione per salvare su un file XML
     * @param nomeFile costante contiene nome del file
     * @param serra
     */
    bool saveInfo(const QString& nomeFile);
    bool loadInfo(const QString& nomeFile);
    void inserisciDato(Dato dato);
    /*
     * @brief modificaDato()    modifica un dato del vettore
     * @param data      definisce la data del dato da modificare
     * @param orario    definisce l'orario del dato da modificare
     * @param dato      definisce il dato da caricare
     * @return bool      true se modificato con successo, false altrimenti
     */
    bool modificaDato(QDate data, QTime orario, Dato dato);
    /*
     * @brief ricercaDato()    ricerca un dato presente nel vettore
     * @param data      definisce la data del dato da ricercare
     * @param orario    definisce l'orario del dato da ricercare
     * @return Dato     ritorna il dato trovato, altrimenti void
     */
    Dato ricercaDato(QDate data, QTime orario) const;
    /*
     * @brief eliminaDato()    elimina un dato presente nel vettore
     * @param data      definisce la data del dato da eliminare
     * @param orario    definisce l'orario del dato da eliminare
     * @return bool      true se eliminato con successo, false altrimenti
     */
    bool eliminaDato(QDate data, QTime orario);
    /*
     * @brief cloneDati()    ritorna una copia del vettore
     */

};

#endif // MODELLO_H
