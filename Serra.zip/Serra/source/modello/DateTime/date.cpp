#include "date.h"

int max (int a, int b)
{
    if (a>b) return(a) ; else return (b);
}

int min (int a, int b)
{
    if (a>b) return(b); else return (a);
}
// constructor definition
Date::Date ()
{
    month = day = year = 1;
}

// Funzione per la verifica della validità della data
bool Date::isValidDate(const int day,const int month,const int year) {
    if (year < 0 || month < 1 || month > 12 || day < 1||day>30)
        return false;
    return true;
}

Date::Date(int dy, int mh, int yr) {
    if (!isValidDate(dy, mh, yr)) {
        throw std::invalid_argument("Data non valida");
    }

    day = dy;
    month = mh;
    year = yr;
}


int Date::getMonth()const{
    return month;
}
int Date::getYear()const{
    return year;
}
int Date::getDay()const{
    return day;
}

std::string Date::toString()const{
    std::string d= std::to_string(day);
    std::string m= std::to_string(month);
    std::string y= std::to_string(year);
    return d+"-"+m+"-"+y;
}
bool Date::operator==(const Date &other) const {
    if(year==other.getYear()&&month==other.getMonth()&&day==other.getDay())
        return true;
    return false;
}
Date Date::convertFromString(const std::string& dateString) {
    Date convertedDate;

    // Utilizzare sscanf per estrarre giorno, mese e anno dalla stringa
    if (std::sscanf(dateString.c_str(), "%d/%d/%d", &convertedDate.day, &convertedDate.month, &convertedDate.year) != 3) {
        throw std::invalid_argument("Formato della stringa non valido");
    }
    if (!isValidDate(convertedDate.day,convertedDate.month,convertedDate.year)){
        throw std::invalid_argument("Data non valida");
    }

    return convertedDate;
}

