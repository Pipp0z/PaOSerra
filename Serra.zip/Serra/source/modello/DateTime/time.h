#ifndef TIME_H
#define TIME_H
#include <string>
#include <stdexcept>
class Time
{
private:
    int seconds;
public:

Time(int sec);
// Funzione per la verifica della validità del tempo
static bool isValidTime(int seconds);

// Funzioni di accesso ai membri privati
int getSecondi() const ;
int getMinuti() const ;
int getOre() const ;
int getSeconds() const;

// Funzione per la rappresentazione del tempo come stringa
std::string toString() const ;
bool operator==(const Time &other) const ;
static int convertToSeconds(const std::string& timeString);
};
#endif // TIME_H
