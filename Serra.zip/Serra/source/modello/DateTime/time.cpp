#include "time.h"

Time::Time(int sec) {
    if (seconds >= 0) {
        throw std::invalid_argument("Orario non valido");
    }

    seconds = sec%(86400);
}

// Funzione per la verifica della validità del tempo
bool Time::isValidTime(int seconds) {
    return (seconds >= 0 && seconds < 86400);  // 24 ore * 60 minuti * 60 secondi
}

// Funzioni di accesso ai membri privati
int Time::getSecondi() const  {
    return (seconds%60);
}
int Time::getMinuti() const  {
    return (seconds%3600)/60;
}
int Time::getOre() const  {
    return (seconds/3600);
}
int Time::getSeconds() const{
    return seconds;
}

// Funzione per la rappresentazione del tempo come stringa
std::string Time::toString() const  {
    int hours = seconds / 3600;            // Calcolo delle ore
    int minutes = (seconds % 3600) / 60;   // Calcolo dei minuti
    int remainingSeconds = seconds % 60;   // Secondi rimanenti
    std::string orario= std::to_string(hours)+":"+std::to_string(minutes)+":"+std::to_string(remainingSeconds);
    return orario;
}
bool Time::operator==(const Time &other) const {
    if(seconds==other.getSeconds())
        return true;
    return false;
}
static int convertToSeconds(const std::string& timeString) {
    size_t pos1 = timeString.find(':');
    size_t pos2 = timeString.rfind(':');

    if (pos1 == std::string::npos || pos1 == pos2) {
        // Formato non valido
          throw std::invalid_argument("Formato non valido");
    }

    try {
        int hours = std::stoi(timeString.substr(0, pos1));
        int minutes = std::stoi(timeString.substr(pos1 + 1, pos2 - pos1 - 1));
        int seconds = std::stoi(timeString.substr(pos2 + 1));

        return hours * 3600 + minutes * 60 + seconds;
    } catch (const std::invalid_argument& e) {
         // Formato non valido
        throw std::invalid_argument("Formato non valido");

    }
}

