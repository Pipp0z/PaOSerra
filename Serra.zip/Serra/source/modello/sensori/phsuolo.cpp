#include "phsuolo.h"
int PHSuolo::tipoSuolo=Suoli::Turba;
PHSuolo::PHSuolo() {}
void PHSuolo::inserisciDato(Dato dato){
    datiSensore.append(dato);

}

bool PHSuolo::modificaDato(Dato dato){
    for (int i = 0; i < datiSensore.size(); ++i) {
        if (datiSensore.at(i).getData() == dato.getData() && datiSensore.at(i).getOrario() == dato.getOrario()){
            datiSensore.replace(i,dato);
            return true;
        }

    }
    return false;
}
Dato PHSuolo::ricercaDato(QDate data, QTime orario) const{
    for (int i = 0; i < datiSensore.size(); ++i) {
        if (datiSensore.at(i).getData() == data && datiSensore.at(i).getOrario() == orario){
            return datiSensore.at(i);
        }

    }
    Dato d("errore");
    return d;
}
bool PHSuolo::eliminaDato(QDate data, QTime orario){
    for (int i = 0; i < datiSensore.size(); ++i) {
        if (datiSensore.at(i).getData() == data && datiSensore.at(i).getOrario() == orario){
            datiSensore.remove(i);
            return true;
        }

    }
    return false;
}

bool PHSuolo::changeStato(int i) {
    tipoSuolo=i;

    return true;
}
QString PHSuolo::getTipoSuolo(){
    switch (tipoSuolo) {
    case 1:
        return "Turba";
        break;
    case 2:
        return  "Sabbiosa";
        break;
    case 3:
        return  "Argillosa";
        break;
    default:
        return "Sconosciuta";
        break;
    }

}

QVector<Dato> PHSuolo::clonaDati() const{
    QVector<Dato> clone;
    if(datiSensore.isEmpty())
        return clone;
    for (int i = 0; i < datiSensore.size(); ++i) {
        clone.append(datiSensore.at(i));
    }
    return clone;
}
