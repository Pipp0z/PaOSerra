#include "salinita.h"

unsigned int Salinita::sogliaSalinita=7;

Salinita::Salinita() {}
void Salinita::inserisciDato(Dato dato){
    datiSensore.append(dato);

}

bool Salinita::modificaDato(Dato dato){
    for (int i = 0; i < datiSensore.size(); ++i) {
        if (datiSensore.at(i).getData() == dato.getData() && datiSensore.at(i).getOrario() == dato.getOrario()){
            datiSensore.replace(i,dato);
            return true;
        }

    }
    return false;
}
Dato Salinita::ricercaDato(QDate data, QTime orario) const{
    for (int i = 0; i < datiSensore.size(); ++i) {
        if (datiSensore.at(i).getData() == data && datiSensore.at(i).getOrario() == orario){
            return datiSensore.at(i);
        }

    }
    Dato d("errore");
    return d;
}
bool Salinita::eliminaDato(QDate data, QTime orario){
    for (int i = 0; i < datiSensore.size(); ++i) {
        if (datiSensore.at(i).getData() == data && datiSensore.at(i).getOrario() == orario){
            datiSensore.remove(i);
            return true;
        }

    }
    return false;
}
QVector<Dato> Salinita::clonaDati() const{
    QVector<Dato> clone;
    if(datiSensore.isEmpty())
        return clone;
    for (int i = 0; i < datiSensore.size(); ++i) {
        clone.append(datiSensore.at(i));
    }
    return clone;
}
bool Salinita::aumentaSalinita(){
    if(sogliaSalinita<=0)
        return false;
    sogliaSalinita--;
    return true;
}
bool Salinita::diminuisciSalinita(){
    if(sogliaSalinita>=10)
        return false;
    sogliaSalinita++;
    return true;
}
int  Salinita::getSalinita(){
    return sogliaSalinita;
}
