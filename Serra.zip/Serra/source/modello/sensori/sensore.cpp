#include "sensore.h"

Sensore::Sensore() {}
